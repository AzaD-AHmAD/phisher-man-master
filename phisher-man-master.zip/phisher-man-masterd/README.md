### Phisher-man
best phishing tool ever made for kali linux work with ngrok 
it has morethan 17 different of phishing page (fake page)

### Usage:
```
git clone https://github.com/AzaD-AHmAD/phisher-man-master.git
cd Phisher-man-master
python phisherman.py
``
AZAD AHMAD
